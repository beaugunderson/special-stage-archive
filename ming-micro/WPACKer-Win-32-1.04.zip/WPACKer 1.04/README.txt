WPACKer version 1.04
Created by Molly Roberts for Special Stage Systems
Updated 10.7.2014

WPACKer is a simple utility for converting .PNG spritesheets into World Pack .TXT files for use with the Ming Mecca World Core.

A spritesheet template, "WPACK_img.PNG" is included in the main folder. The template is organized as follows:

 -------------------
|		    |
| X X X X X	    |	from left to right, 
|		    |	color 0, 1, 2, 3, and boot logo
|                   |
| x x x x x x x x   |	maps
| x x x x x x x x   |
|		    |
|                   |
| X X X X   X X X X |	tiles (left) and sprites (right)	
| X X X X   X X X X |
| X X X X   X X X X |
| X X X X   X X X X |
| X X X X   X X X X |
| X X X X   X X X X |
| X X X X   X X X X |
| X X X X   X X X X |
|                   |
 -------------------

You can use any image editing application to modify the template and create your art. Refer to the Ming Mecca user's guide for more information on creating World Packs. 

Once your spritesheet is complete, perform the following steps to convert in into a World Pack text file:

1. Place the spritesheet in the same folder as the WPACKer application

2. Make sure the spritesheet is named "WPACK_img.PNG" -WPACKer will only process files with this name.

3. Launch WPACKer

4. WPACKer will create your World Pack text file in its root folder.

5. Place the resulting text file on your SD Card, and rename it to WPACK.TXT.


Notes:

1. WPACKer does not currently generate palettes. The World Core's built-in palettes will be used by default, or custom palettes can be entered by hand. Refer to the Ming Mecca User's guide for more information on creating palettes.

2. WPACKer will display your spritesheet with the same rendering dimensions (pixel aspect ratio) as the World Core. This is useful for checking the proportions of your work.