/*
 * MING MECCA
 * CONTROL CORE FIRMWARE V2.01
 * WRITTEN BY JORDAN BARTEE FOR SPECIAL STAGE SYSTEMS
 * WINTER 2012
 */

//==============================================================================
//INCLUDES

#include <p24HJ64GP502.h>           //Microchip header file
#include <adc.h>                    //Microchip header file
#define FCY 20000000UL              //Needed to calibrate delay timing in libpic30.h
#include <libpic30.h>               //Some nice delay functions that we'll use for blinkenlights

//==============================================================================

//==============================================================================
// CONFIGURE THE PIC

_FBS(BWRP_WRPROTECT_OFF);                           //Disable boot segment write protection
_FGS(GSS_OFF  & GCP_OFF & GWRP_OFF);                //No general segment protection either
_FWDT(FWDTEN_OFF & WINDIS_OFF & WDTPRE_PR128 & WDTPOST_PS512);          //Disable watchdog timer
_FOSCSEL(FNOSC_FRC & IESO_OFF);                     //Boot with the internal 7.37 MHz FRC (later we'll switch to 40 MHz PLL in the main function)
_FOSC(FCKSM_CSECMD & POSCMD_XT);                    //Enable clock switching, use the primary oscillator in XT mode
_FPOR(ALTI2C_OFF & FPWRT_PWR32);                    //Set the POR at 32ms just as a precaution against weirdness
_FICD(JTAGEN_OFF & ICS_PGD1);                       //No JTAG

//==============================================================================

//==============================================================================
//DECLARE VARIABLES
unsigned int nes_buttons [8];    //Holds the button states scanned from the controller
unsigned char i = 1;            //Used in scanNES
unsigned char x;                 //Value for analog X output
unsigned char y;                 //Value for analog Y output
unsigned int xy_speed = 4;       //Speed at which X / Y outs increment / Decrement
unsigned int i_count_x;           //Used in the X incrementing counter
unsigned int d_count_x;           //Used in the X decrementing counter
unsigned int i_count_y;           //Used in the Y incrementing counter
unsigned int d_count_y;           //Used in the Y decrementing counter
unsigned int turbo_count;        //Sets the period of the turbo square oscillator


//Values for Turbo Number of Repeats
unsigned int turbo_n_holder[17] = {0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 24, 28, 32, 48, 64, 75};

//Values for speed of X / Y increment / decrement
unsigned int count_max[8] = {2000, 1000, 500, 200, 150, 100, 50, 10};

unsigned int turbo_r;         //Rate of turbo fire
unsigned int turbo_n;         //Number of repetitions of turbo fire
unsigned int turbo_n_old;      //Holds the old value for use in the anti-flip routine
unsigned int anti_count;         //Used in anti-flip routine
unsigned int anti_count1;        //Used in anti-flip routine

unsigned int start_flag;         //Used for X / Y increment
unsigned int sel_flag;           //Used for X / Y decrement
unsigned int turbo_flag;         //Sets "hard reset" for turbo square oscillator
unsigned int turbo_delay;	 //Counts delay time in Japan mode
unsigned int turbo_delay_gate;	//Used for delay 
unsigned int trig;              //Signals turbo ISR that a trigger is received at turbo input
unsigned int AN0_hold;		//ADC value for rate
unsigned int AN1_hold;           //ADC value for number of repeats
unsigned int au2_bufferA[2] __attribute__((space(dma),aligned(4)));   //This array is used to store the ADC results

unsigned int scan_count;           //Used in scanNES to set clock width
unsigned int scan_flag;            //Used in scanNES to ensure it latches only once per scan cycle

unsigned char gate;               //Gates the turbo oscillator
unsigned int flip_count;           //Used by turbo ISR to tell main function its current cycle

unsigned long int c;              //If I told you what these variables do I'd have to kill you.
unsigned int d;                   //They are explained somewhat in the comments if you're really curious.
unsigned int cheat;
unsigned long int cheat_count;
unsigned int test;
unsigned int konami [12] = {5, 5, 6, 6, 7, 8, 7, 8, 2, 1, 4, 75};
unsigned int ch;
unsigned char konami_flag;
unsigned char kon[8] = {0, 0, 0, 0, 0, 0, 0, 0};
unsigned char note;
unsigned char miserable_pile;
unsigned int blinky_treasure;
unsigned int lpg;
unsigned char lpg_off;
unsigned char lpg_flag;
unsigned int lpg_count;
unsigned char lpg_mode;


#define state_number (1024/17)    //Sets resolution of number of repeats CV
#define rotate_smoothing 25        //Sets amount of "smoothing" applied to ADC inputs in the anti-flip routine

//==============================================================================
//FUNCTIONS


/* In this ISR data is moved from the DMA buffer into an array
 * that we'll access from the while-loop. It uses the waiting flag to
 * interact with the main function.
 */

volatile  unsigned int    au2_buffer[2];
volatile  unsigned char   waiting;

void _ISRFAST _DMA0Interrupt(void)
  {
    unsigned char d;                          //Used in the for-loop.
    unsigned int* au2_adcHWBuff = (unsigned int*) &au2_bufferA;               //This is a pointer that we'll use to access au16_bufferA.
    _DMA0IF = 0;                              //Clear the interrupt flag status.

    if (waiting)                              //The while-loop sets waiting high
      {
        for ( d=0; d<2; d++)                  //This moves the data from DMA buffer to our array
          {
            au2_buffer[d] = au2_adcHWBuff[d]; //i increments through the contents one word at a time until our array is full
          }

        waiting = 0;                          //Ding! Your data is ready.
      }
  }

//==============================================================================
/* This ISR references T1 for precise timing, and generates the
 * Turbo Out square wave oscillator.
 */

void _ISR _T1Interrupt(void)
  {
    if (lpg_mode == 0)
    {
    turbo_count++;                     //Increment turbocount
    if (turbo_count > turbo_r)       //Check turbocount against turborate (sets the period)
      {
        turbo_count = 0;               //Reset turbocount
        if (gate == 1)                //Check the Gate status to see if main function is signalling that Turbo should be active
          {
            _LATB14 = !_LATB14;       //Invert that state of turbo out pin
            flip_count = flip_count++;  //Increment flipcount, this tells the main function how many oscillations have occurred

            if (miserable_pile == 1)   //See if something secret is happening, and flash LEDs if it is
              {
                _LATB2 = !_LATB2;
                _LATB3 = !_LATB2;
                _LATB4 = !_LATB4;
                _LATB5 = !_LATB4;
                _LATB12 = !_LATB12;
                _LATB13 = !_LATB12;
              }
          }                           //(used to set number of repeats)
          else
            {
              flip_count = 0;          //Safety; force flipcount to zero if not oscillating
            }
      }
    }
    else
    {

     if (_RB9 == 1)                      //Check Turbo input
                  {
                    turbo_count = 0;                 //Reset turbocount and flipcount (bug prevention)
                    flip_count = 0;
                    if (lpg_off == 0)                //Prevents retriggering until turbo input resets
                        {

                            if (lpg <= turbo_r)          //Counter to set pulse width
                                {
                                    _LATB14 = 1;    //Turbo out high
                                    lpg++;          //Increment counter
                                }
                                else
                                    {
                                        _LATB14 = 0;	//Turbo out low
                                        lpg = 0;    	//reset counter
                                        lpg_off = 1; 	//Stop after one pulse (no retrigger)
                                    }
                        }
                  }
                  else
                    {
                    if (_RB14 == 1)                     //If turbo out is high, we don't want to interrupt it if
                    {                                   //turbo in goes low, so we copy the structure from above.
                        if (lpg_off == 0)                //Prevents retriggering until turbo input resets
                        {


                            if (lpg <= turbo_r)          //Counter to set pulse width
                                {
                                    _LATB14 = 1;    //Turbo out high
                                    lpg++;          //Increment counter
                                }
                                else
                                    {
                                        _LATB14 = 0;	//Turbo out low
                                        lpg = 0;    	//reset counter
                                        lpg_off = 1; 	//Stop after one pulse (no retrigger)
                                    }
                        }
                    }
                    else
                    {
                      turbo_count = 0;               //Reset turbocount and flipcount (bug prevention)
                      flip_count = 0;
                      lpg = 0;                      //Reset LPG mode counter
                      lpg_off = 0;                   //Reset LPG mode anti-retrigger
                      _LATB14 = 0;                  //Turbo out low
                    }
                    }
    }
    IFS0bits.T1IF = 0;                //Clear Timer1 Interrupt Flag
  }
//==============================================================================
/* The scanNES function bangs in the serial data from the NES controller
*/

void scanNES (void)
  {
    if(scan_flag == 0)           //Check against scanflag so that the latch routine only occurs once per scan
      {
        _LATB7 = 0;             //Initialize clock low
        _LATB6 = 1;             //Latch
        __delay_ms(1);          //Wait 1 ms to give the pulse some width
        _LATB6 = 0;             //End latch
        nes_buttons[0] = _RB8;   //Write controller data to position 0 (A button) of our array
                                //Due to the controller architecture, A is scanned directly at the latch before we go into the main clock train
        scan_flag = 1;           //Set scanflag high so we don't repeat this until the next scan
      }

    scan_count++;                //We setup a little counter here to set the clock width without resorting to delays
    _LATB7 = 1;                 //This allows the main loop to conitnue iterating at optimum speed even when scanNES is called

    if (scan_count > 96)
      {
        _LATB7 = 0;
        nes_buttons[i] = _RB8;   //Each time we iterate a clock cycle, move to the next position of the array and write in the controller data
        i++;
        scan_count = 0;          //Reset the clock counter
      }

    if (i > 7)                  //When we reach the 8th position of the array, reset i (remember that position 0 is written during the latch,
      {                         //hence why i = 1 rather than 0) and turn off scanflag so that we initiate a brand new scan cycle on the next iteration.
        i = 1;
        scan_flag = 0;
      }
    }

//==============================================================================

//==============================================================================
//MAIN

int main (void)
  {

//==============================================================================
    //First we have to set up the PLL and then perform a real-time clock switch so that we can run at 20 MIPS

    PLLFBD=41;                              //The feedback divisor is actually set at 43 (number gets added to the default of 2)
    CLKDIVbits.PLLPOST=0b01;                //Set post scaler to 4
    CLKDIVbits.PLLPRE=0;                    //Set prescaler to 2

    asm("DISI #0x3FFF");                    //Now we disable interrupts so nothing gets weird while performing the clock switch
    asm("MOV #0x01,w0");                    //Select FRC + PLL as our destination

    //Then we copy and paste a bunch of magic from section 7 of the PIC24H datasheet

    asm("MOV #OSCCONH, w1");                //High byte unlock sequence
    asm("MOV #0x78, w2");
    asm("MOV #0x9A, w3");
    asm("MOV.B w2, [w1]");
    asm("MOV.B w3, [w1]");

    asm("MOV.B w0, [w1]");                  //Request clock switching
    asm("MOV #0x01, w0");                   //Enable clock switching

    asm("MOV #OSCCONL, w1");                //Low byte unlock sequence
    asm("MOV #0x46, w2");
    asm("MOV #0x57, w3");
    asm("MOV.B w2, [w1]");
    asm("MOV.B w3, [w1]");
    asm("MOV.B w0, [w1]");

    asm("DISI #0");                         //Now that the magic has happened, we re-enable interrupts
    while (_OSWEN == 1) { }                 //Wait until this flag signals that the switch was successful

//==============================================================================

     //Now we configure the two PWM channels

    _RP0R = 18;                         //Map PWM1 to physical pin 4
    _RP1R = 19;                         //Map PWM2 to physical pin 5

    //Disable Output Compare Modules for both Channels
    OC1CONbits.OCM = 0b000;
    OC2CONbits.OCM = 0b000;

    //Set the duty cycle for PWM pulse1 to 100
    OC1R = 100;
    OC2R = 100;

    //Set the duty cycle for PWM pulse2 to 200
    OC1RS = 200;
    OC2RS = 200;

    OC1CONbits.OCM = 0b110;             //Select PWM mode, no need for fault protection
    OC2CONbits.OCM = 0b110;

    OC1CONbits.OCTSEL = 0;              //Use Timer 2 as the clock source
    OC2CONbits.OCTSEL = 0;
    T2CONbits.TON = 0;                  //Disable the timer
    T2CONbits.TCS = 0;                  //Use the internal clock (FCY)
    T2CONbits.TGATE = 0;                //Disable gated timer mode
    T2CONbits.TCKPS = 0b01;             //Prescaler set to 1:8 ratio
    TMR2 = 0x00;                        //Clear the timer register
    PR2 = 250;                          //Load the period value
    T2CONbits.TON = 1;                  //Enable the timer


    T1CONbits.TON = 0;                  //Disable Timer
    T1CONbits.TCS = 0;                  //Select internal instruction cycle clock
    T1CONbits.TGATE = 0;                //Disable Gated Timer mode
    T1CONbits.TCKPS = 0b00;             //Select 1:1 Prescaler
    TMR1 = 0x00;                        //Clear timer register
    PR1 = 4999;                         //Load the period value
    IPC0bits.T1IP = 0x01;               //Set Timer1 Interrupt Priority Level
    IFS0bits.T1IF = 0;                  //Clear Timer1 Interrupt Flag
    IEC0bits.T1IE = 1;                  //Enable Timer1 interrupt
    T1CONbits.TON = 1;                  //Start Timer


//==============================================================================
     //Configure the I/O

    TRISB = 0b0000011100000000;                   //RB6 = LAT out    RB7 = CLK in    RB8 = DATA in   RB9 = turbo in    RB10 = toggle in
    TRISA = 0b0000000000000011;                   //Set AN0-1 to inputs
    AD1PCFGL =  0b0001111111111100;               //Everything digital except AN0-1, which will be our two CV inputs
    AD1CSSL = 0b0000000000000011;                 //Turn on scanning for AN0-1

//==============================================================================
    //Configure the ADC

    AD1CON1bits.ADON = 0;               //First we disable the ADC so it doesn't spaz out while we configure it
    AD1CON1bits.SSRC = 7;               //Use internal counter for auto-conversion
    AD1CON1bits.ASAM = 1;               //Auto-set the SAMP bit
    AD1CON1bits.ADDMABM = 0;            //Use scatter/gather mode for DMA

    AD1CON2bits.VCFG = 0;               //Use VDD and VSS for ADC reference voltage
    AD1CON2bits.CSCNA = 1;              //Enable input scanning for CH0
    AD1CON2bits.CHPS = 0;               //Convert CH0
    AD1CON2bits.SMPI = 4;               //Generate our DMA interrupt every 4 operations
    AD1CON3bits.ADRC = 0;               //Derive the ADC clock from the System Clock
    AD1CON3bits.SAMC = 1;               //Auto-sampling time set to 1 TAD
    AD1CON3bits.ADCS = 2;               //Conversion clock yields TAD value of 75 nS

    AD1CON4 = 0;                        //DMA Buffer is one word long
    DMA0CONbits.AMODE = 2;              //DMA placed in peripheral indirect mode (this is needed for scatter/gather mode)


    //Setup the DMA CH0 interrupt
    DMA0PAD = (unsigned int) &ADC1BUF0;             //Attach DMA0 to the ADC buffer
    DMA0REQbits.IRQSEL = 0b00001101;                //This binds DMA0 to the ADC1 peripheral
    DMA0STA = __builtin_dmaoffset(au2_bufferA);     //Point DMA0 to Buffer A
    DMA0CNT = 3;                                    //The buffer will store 4 words at a time
    DMA0CONbits.SIZE = 0;                           //It's one word long
    DMA0CONbits.DIR = 0;                            //Read from the ADC1 peripheral and write the data to DPSRAM address
    DMA0CONbits.HALF = 0;                           //Cause an Interrupt once all our data's been safely moved
    DMA0CONbits.NULLW = 0;                          //Normal operation
    DMA0CONbits.MODE = 0;                           //DMA mode is continuous.  Ping-Pong disabled.

    _DMA0IF = 0;                //Clear DMA CH0 interrupt
    _DMA0IP = 6;                //It doesn't really matter what priority level we assign the interrupt, so we'll just put it at 6
    _DMA0IE = 1;                //Enable DMA CH0 interrupt

    DMA0CONbits.CHEN = 1;               //Turn on DMA0 module
    AD1CON1bits.ADON = 1;               //Turn on the ADC

    waiting = 1;   //Initialize waiting flag high (used by while loop to talk to ADC function)


//==============================================================================
    //A bunch of secret stuff happens here that you shouldn't look at

    for (c=0;c < 1000;c++)                //When the module is first powered on, turbo out goes high for a few seconds to indicate
      {                                   //a happy module.  Something secret can also happen here.
        OC1RS = 0;                        //Initialize PWM low to prevent LED flashing
        OC2RS = 0;
        _LATB14 = 1;                      //Turn on turbo out to indiciate power cycle (Hello World!)
        scanNES();                        //Scan the controller so we have input

        if(nes_buttons[1] == 0)            //If Select and B are held down, set cheat high
          {
            if (nes_buttons[2] == 0)
              {
                cheat = 1;
              }
              else
                {
                  cheat = 0;
                }
          }
          else
            {
              cheat = 0;
            }

            __delay_ms(1);
      }

    if (cheat == 1)                       //If cheat is high, enter the super secret input mode
      {
        for (c = 0;c < 600000;c++)        //Super secret input mode lasts for a fixed duration
          {
            scanNES();                    //Scan the controller for the secret password

            for (d = 0;d < 8;d++)
              {
                if(nes_buttons[d] == 0)
                  {
                    __delay_us(100);        //Heavy debounce doubles as "confidence test," user must enter password somewhat slowly

                    if(nes_buttons[d] == 0)  //Iterate through each button in the array.  If it's being depressed,
                      {                     //set test to the current iteration number plus 1, set the current kon value to 0.
                        test = d + 1;
                        kon[d] = 0;
                      }
                      else
                        {
                          kon[d] = 1;       //Otherwise all kon positions always equal 1
                        }
                  }
                  else
                    {
                      kon[d] = 1;
                    }
              }

            if (kon[0] + kon[1] + kon[2] + kon[3] + kon[4] + kon[5] + kon[6] + kon[7] == 8)   //If the sum of the array equals 8, then no buttons
              {                                                                               //are currently depressed. This is so that if the user
                konami_flag = 1;                                                               //holds a button down, it doesn't immediately error out
              }                                                                               //as an incorrect button in the code sequence.

            if (konami_flag == 1)
              {
                if (kon[0] + kon[1] + kon[2] + kon[3] + kon[4] + kon[5] + kon[6] + kon[7] == 7) //Same idea here, except we check that one and only one
                  {                                                                             //button is depressed to weed out button mashers.
                    if (test == konami[ch])               //Test is basically a unique button ID that represents the currently depressed button.
                      {                                   //We check it against an array that contains the correct button sequence. If it matches, then
                        konami_flag = 0;                   //we step to the next position in the array and restart the whole check sequence above.
                        ch++;

                        if (konami[ch] == 75)             //$75 is the win state.  If we've hit the win state, then we play the win melody out of
                          {                               //turbo out jack.
                            while (note < 16)
                              {
                                _LATB14 = !_LATB14;
                                __delay_ms(1);

                                switch (note)             //These determine the pitches (set by trial and error)
                                  {
                                    case 1:
                                      __delay_us(250);
                                      __delay_us(250);
                                      __delay_us(250);
                                      __delay_us(250);
                                    break;

                                    case 2:
                                      __delay_us(1000);
                                      __delay_us(1000);
                                      __delay_us(1000);
                                      __delay_us(1000);
                                      __delay_us(1000);
                                      __delay_us(1000);
                                    break;

                                    case 3:
                                      __delay_us(400);
                                      __delay_us(400);
                                      __delay_us(400);
                                      __delay_us(400);
                                    break;

                                    case 4:
                                      __delay_us(500);
                                      __delay_us(500);
                                      __delay_us(500);
                                      __delay_us(500);
                                    break;
                                  }

                                cheat_count++;

                                if (cheat_count > 50)      //A simple counter to control the rate we do crazy LED flashing
                                  {
                                    _LATB2 = !_LATB2;
                                    _LATB3 = !_LATB2;
                                    _LATB4 = !_LATB4;
                                    _LATB5 = !_LATB4;
                                    _LATB12 = !_LATB12;
                                    _LATB13 = !_LATB12;

                                    cheat_count = 0;
                                    note++;
                                  }
                              }

                            _LATB2 = 0;                   //Dramatic pause
                            _LATB3 = 0;
                            _LATB4 = 0;
                            _LATB5 = 0;
                            _LATB12 = 0;
                            _LATB13 = 0;
                            _LATB14 = 0;

                            __delay_ms(500);
                            __delay_ms(500);
                            __delay_ms(500);
                            __delay_ms(500);
                            __delay_ms(500);
                            __delay_ms(500);

                            while(1)                                  //A miserable little pile of secrets
                              {

                                while (waiting){};

                                miserable_pile = 1;                    //Signal LED madness
                                PR1 = 99;                             //Set the period of TM1 to achieve a much wider
                                                                      //range of oscillation at turbo out

                                if (au2_buffer[1] > 1010)             //Disable modulation if CV is above a certain threshold
                                  {
                                    gate = 1;
                                  }
                                  else
                                    {
                                      scan_count++;
                                      if(scan_count > au2_buffer[1])   //Sets rate of modulator (amplitude)
                                        {
                                          gate = !gate;
                                          scan_count = 0;
                                        }
                                    }

                                turbo_r = au2_buffer[0];            //Sets frequency of carrier
                                waiting = 1;

                              }
                          }
                      }
                      else                                            //If test doesn't pass the check, we restart the array to the 0 position
                        {
                          ch = 0;
                        }
                  }
              }

            cheat_count++;

            if (cheat_count > 5000)
              {
                _LATB2 = !_LATB2;
                _LATB3 = !_LATB3;
                _LATB4 = !_LATB4;
                _LATB5 = !_LATB5;
                _LATB12 = !_LATB12;
                _LATB13 = !_LATB13;
                cheat_count = 0;
              }

          }
      }

    _LATB14 = 0;

//==============================================================================

//==============================================================================
//WHILE

    while(1)
      {
      	scanNES();	//Call the controller scanning function.

        //Set the gate outputs according the state of each button in the array.  The delays form a basic debounce routine.
        if (nes_buttons[0] == 0)   //A
          {
            __delay_us(15);
            if (nes_buttons[0] == 0)
              {
                _LATB3 = 1;
              }
          }
          else
            {
              _LATB3=0;
            }

        if (nes_buttons[1] == 0)   //B
          {
          __delay_us(15);
          if (nes_buttons[1] == 0)
            {
              _LATB2 = 1;
            }
          }
          else
            {
              _LATB2=0;
            }

        if (nes_buttons[4] == 0)   //Up
          {
            __delay_us(15);
            if (nes_buttons[4] == 0)
              {
              _LATB4 = 1;
              }
          }
          else
            {
              _LATB4=0;
            }

        if (nes_buttons[5] == 0)   //Down
          {
            __delay_us(15);
            if (nes_buttons[5] == 0)
            {
              _LATB5 = 1;
            }
          }
          else
            {
              _LATB5=0;
            }

        if (nes_buttons[6] == 0)   //Left
          {
            __delay_us(15);
            if (nes_buttons[6] == 0)
              {
                _LATB12 = 1;
              }
          }
          else
            {
              _LATB12=0;
            }

        if (nes_buttons[7] == 0)   //Right
          {
            __delay_us(15);
            if (nes_buttons[7] == 0)
              {
                _LATB13 = 1;
              }
          }
          else
            {
              _LATB13=0;
            }


/* The Start and Select buttons have special functions and do not trigger gate outputs.  Instead they are used
 * to increment and decrement the speed of the X / Y analog outputs.
 */

        if (nes_buttons[3] == 0)   //Select
          {
            if (start_flag == 0)   //start_flag makes sure that the speed is incremented only once per
              {                   //button press, even if the button is held down
                start_flag = 1;

                if (xy_speed < 8)
                  {
                    xy_speed++;
                  }
                  else
                    {
                      xy_speed = 7; //Constrict the range so we don't overshoot the array size
                    }
              }
          }
          else
            {
              start_flag = 0;      //When Select isn't currently depressed (i.e, once the finger has lifted),
            }                     //start_flag returns to zero to that xy_speed can be incremented again.



        if (nes_buttons[2] == 0)   //Start
          {
            if (sel_flag == 0)     //This structure exactly mirrors the code for Select, except that we decrement xy_speed
              {
                sel_flag = 1;

                  if (xy_speed > 0)
                    {
                      xy_speed--;
                    }
                    else
                      {
                        xy_speed = 0;
                      }
              }
          }
          else
            {
              sel_flag = 0;
            }

/* Now we anaylze what's going on with the D-pad and set our X / Y variables.
 */

        //Y---Y---Y---Y---Y---Y---Y---Y---Y---Y---Y---Y---Y---Y---Y---Y---Y---Y

        if (nes_buttons[4] == 0)   //Up
          {
            if (y < 250)                              //Maximum Y value
              {
                i_count_y++;                            //Increment i_count_y each time the loop iterates

                if (i_count_y >= count_max[xy_speed])     //Here's where we actually set the speed as determined by Start / Select
                  {                                   //xy_speed selects a value from the count_max array which sets the number of counts
                    y++;                              //When the maximum count is reached, we increment Y by 1, and reset the counter
                    i_count_y = 0;
                  }
              }
              else
                {
                  y = 250;                            //Restrict range
                }
          }

        if (nes_buttons[5] == 0)   //Down
          {
            if (y > 0)                                //Same structure as above, except we decrement y
              {
                d_count_y++;

                if (d_count_y >= count_max[xy_speed])
                  {
                    y--;
                    d_count_y = 0;
                  }
              }
              else
                {
                  y = 0;
                }
          }

        //X---X---X---X---X---X---X---X---X---X---X---X---X---X---X---X---X---X

        if (nes_buttons[7] == 0)   //Right
          {
            if (x < 250)   	   //Same structure as above
              {
                i_count_x++;

                if (i_count_x >= count_max[xy_speed])
                  {
                    x++;
                    i_count_x = 0;
                  }
              }
              else
                {
                  x = 250;
                }
          }

        if (nes_buttons[6] == 0)   //Left
          {
            if (x > 0)             //Same structure as above
              {
                d_count_x++;

                if (d_count_x >= count_max[xy_speed])
                  {
                    x--;
                    d_count_x = 0;
                  }
              }
              else
                {
                  x = 0;
                }
          }

        if (xy_speed > 7)
          {
            xy_speed = 7;	//Just make extra double superduper sure we never exceed the maximum array value
          }


        OC1RS = x;              //Finally we set the PWM outputs to equal the values at X and Y
        OC2RS = y;

        /*Now we deal with the CV inputs and set up the turbo / rapid fire system.
         */

        while (waiting){};    	//Pause until the ADC results are ready in our DMA function.





        //Turbo Rate
        if (lpg_mode == 0)
            {
                turbo_r = (((au2_buffer[0] * 4) -4096) * -1) +32;	//invert and scale to LFO range
            }
        else
            {
                turbo_r = ((au2_buffer[0] -1024) * -1);                 //Invert, but don't scale so that we can achieve nS trigger times in LPG mode
            }






        //Turbo Number of Repeats ("steps")

        AN1_hold = au2_buffer[1] / state_number;      //Reduce the ADC resolution by state_number
                                                    //AN0hold is used to index an array with our number of repeats


 /*This is an "anti-flip" routine to reduce unwanted state oscillation on the CV inputs
 */
        if (turbo_n_holder [AN1_hold] == turbo_n_old)   //Compare current and old number of repeats
                {
                    anti_count1 = anti_count1++;     //If these are the same, increment anti_count
                }

            else                                    //If they're different, reset anti_count
                {
                    anti_count1 = 0;
                }

        if (anti_count1 >= rotate_smoothing)
          {
            turbo_n = turbo_n_holder [AN1_hold]; //When anti_count passes a threshold set turbo_n and reset anti_count
            anti_count1 = 0;
          }

        turbo_n_old = turbo_n_holder [AN1_hold];    //Store the current rate for the next cycle

        /*Depending on the state of the Turbo Mode Toggle, we enter either Turbo Mode or Retrigger mode. First we hash out
         *Retrigger mode, which starts oscillating when a trigger is received at turbo in, and lasts for a certain number
         *of repeats as specified by CV
         */

        if (_RB10 == 1)                             //Check Turbo Mode Toggle = Sweden
          {
            if (turbo_n == 0)                     //This takes care of an edge case: if number of repeats is 0,
              {                                   //The turbo output truncates to a single fast pulse for use with LPGs.

                lpg_mode = 1;
              }
              else                                  //If number of repeats is above 0, we
                {			            //proceed to the rest of the turbo routine.
                  lpg_mode = 0;
                  if (turbo_n >= 75)              //Another edge case; check if number of repeats
                    {                               //is greater than 75, if yes begin infinite repeats.
                      if (_RB9 == 1)                //Check turbo input.
                        {

                        /*Turboflag is used to initiate a sort of "hard reset" so that turbo always starts high.
                         *The first time turbo in goes high, all variables relating to turbo oscillation are reset, and turbo out
                         *is immediately set high.  Subsequent iterations are prevented from reseting the turbo Output again by
                         *turboflag until turbo Input has cycled.
                         */

                          if (turbo_flag == 1)       //Begin "hard reset" if turbo_flag is high
                            {
                              turbo_count = 0;       //Reset variables so turbo oscillation is initialized
                              flip_count = 0;
                              _LATB14 = 1;          //Set turbo out high
                            }

                          turbo_flag = 0;            //Set turboflag low (prevent further hard resets)
                          gate = 1;                 //Signal the turbo ISR that it should start oscillating
                        }
                    }
                  else                              //If number of repeats is below, enter normal operation
                      {
                        if (_RB9 == 1)              //Check turbo input
                          {
                            if (turbo_flag == 1)     //"Hard reset," same structure as above, except
                              {                     //we reset gate to 0 (bug prevention), and set trig high
                                gate = 0;
                                turbo_count = 0;
                                flip_count = 0;
                                _LATB14 = 1;
                                trig = 1;
                              }

                            turbo_flag = 0;
                          }
                          else
                            {
                              turbo_flag = 1;        //Set turbo_flag high when cycle is complete
                            }

                  if (flip_count <= turbo_n)       //flip_count is incremented by the turbo ISR to express the current number
                    {                               //of completed cycles.  Check that it's less than the number of steps set by CV
                      if (trig == 1)                //Trig makes sure that we only signal the turbo ISR if we've received a trigger
                        {                           //at the turbo input and completed a "hard reset"
                          turbo_flag = 0;            //Safety: set turbo_flag low (bug prevention)
                          gate = 1;                 //Signal the turbo ISR that it should start oscillating
                        }
                    }
                    else
                      {
                        _LATB14 = 0;                //Turn everything off once maximum number of steps has been reached
                        trig = 0;
                        flip_count = 0;
                        gate = 0;
                      }

                      }
              }
          }

        /* In Turbo Mode, turbo out oscillates only while a gate high is present at the turbo input
	*/

          else                                      //Check Turbo Mode Toggle
            {
              if (_RB9 == 1)                        //Check turbo input
                {
                  lpg_mode = 0;
                  if (turbo_delay_gate == 1)                //Only count a delay during first cycle as determined by turbo_delay_gate
                    {
                      turbo_delay++;
                    }

                  if (turbo_delay >= (au2_buffer[1]*24))    //Number of repeats CV determines pre-turbo delay time.
                    {
                        if (turbo_flag == 1)               //"Hard reset," same structure as above
                            {
                                turbo_count = 0;
                                flip_count = 0;
                                _LATB14 = 1;
                            }
                        turbo_delay_gate = 0;
                        turbo_flag = 0;
                        gate = 1;                         //Signal the turbo ISR that it should start oscillating
                    }
                }
                else
                  {
                    turbo_flag = 1;                  //Set turbo_flag high when cycle is complete
                    turbo_delay_gate = 1;
                    gate = 0;                       //Turn off oscillation in the ISR
                    turbo_delay = 0;
                    _LATB14 = 0;                    //Force turbo out to 0
                  }

            }

        waiting = 1;                                //Set waiting high to pause for ADC results during next iteration

      }   //end of while(1)
  }   //end of main()